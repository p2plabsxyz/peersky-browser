import { isWebkit, getBrowser } from './browser-info.js';

const SUPPORTED_FILTERS = ["platform", "browser", "version"];
function filter(item) {
  if (item.filter) {
    let check = Object.keys(item.filter).every((key) => {
      if (!SUPPORTED_FILTERS.includes(key)) {
        console.warn(`[config] Unsupported filter key: ${key}`);
        return false;
      }
      return true;
    });
    if (check && Array.isArray(item.filter.platform)) {
      let platform;
      {
        platform = isWebkit() ? "webkit" : "chromium";
      }
      check = item.filter.platform.includes(platform);
    }
    if (check && typeof item.filter.browser === "string") {
      check = getBrowser().name === item.filter.browser;
    }
    if (check && typeof item.filter.version === "string") {
      const version = chrome.runtime.getManifest().version.split(".").map((n) => parseInt(n, 10));
      const filterVersion = item.filter.version.split(".").map((n) => parseInt(n, 10));
      for (let i = 0; i < filterVersion.length; i += 1) {
        const v = version[i];
        const f = filterVersion[i];
        if (v > f) {
          break;
        }
        if (v < f) {
          check = false;
          break;
        }
      }
    }
    return check;
  }
  return true;
}

export { filter };
