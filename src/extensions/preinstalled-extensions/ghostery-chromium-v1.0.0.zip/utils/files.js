import getBrowserInfo from './browser-info.js';

function saveAs(url, filename) {
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.dispatchEvent(new MouseEvent("click"));
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
function saveOrOpenTab(url, filename, forceNewTab = false) {
  if (forceNewTab) {
    return chrome.tabs.create({
      url: url.startsWith("data:") ? url : chrome.runtime.getURL(
        "pages/download/index.html?url=" + encodeURIComponent(url) + "&filename=" + encodeURIComponent(filename)
      )
    });
  }
  return saveAs(url, filename);
}
async function download({
  data,
  filename,
  type = "application/json;charset=utf-8;",
  forceNewTab = false
}) {
  const blob = new Blob([data], { type });
  {
    const { os } = await getBrowserInfo();
    if (os === "ios" || os === "ipados") {
      const fileReader = new FileReader();
      return new Promise((resolve, reject) => {
        fileReader.onload = () => {
          saveOrOpenTab(fileReader.result, filename, forceNewTab);
          resolve();
        };
        fileReader.onerror = reject;
        fileReader.readAsDataURL(blob);
      });
    }
  }
  const url = URL.createObjectURL(blob);
  await saveOrOpenTab(url, filename, forceNewTab);
}

export { download, saveAs };
