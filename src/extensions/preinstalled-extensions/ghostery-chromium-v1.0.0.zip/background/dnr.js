import { isGloballyPaused, ENGINES } from '../store/options.js';
import Resources from '../store/resources.js';
import { getDynamicRulesIds, filterMaxPriorityRules, FIXES_ID_RANGE } from '../utils/dnr.js';
import { addListener } from '../utils/options-observer.js';
import { ENGINE_CONFIGS_ROOT_URL } from '../utils/urls.js';
import { UPDATE_ENGINES_DELAY } from './adblocker/index.js';
import { updateRedirectProtectionRules } from './redirect-protection.js';
import store from '../npm/hybrids/src/store.js';

{
  let getIds = function(options) {
    if (!options.terms || isGloballyPaused(options)) return [];
    const ids = ENGINES.reduce((acc, { name, key }) => {
      if (options[key] && DNR_RESOURCES.includes(name)) acc.push(name);
      return acc;
    }, []);
    if (ids.length && options.regionalFilters.enabled) {
      ids.push(
        ...options.regionalFilters.regions.map((id) => `lang-${id}`).filter((id) => DNR_RESOURCES.includes(id))
      );
    }
    if (ids.length && options.redirectProtection.enabled && DNR_RESOURCES.includes("redirect-protection")) {
      ids.push("redirect-protection");
    }
    return ids;
  };
  const DNR_RESOURCES = chrome.runtime.getManifest().declarative_net_request.rule_resources.filter(({ enabled }) => !enabled).map(({ id }) => id);
  const DNR_FIXES_KEY = "dnr-fixes";
  addListener(async function dnr(options, lastOptions) {
    const ids = getIds(options);
    if (lastOptions && lastOptions.filtersUpdatedAt === options.filtersUpdatedAt && lastOptions.fixesFilters === options.fixesFilters && String(ids) === String(getIds(lastOptions))) {
      return;
    }
    const enabledRulesetIds = await chrome.declarativeNetRequest.getEnabledRulesets() || [];
    const resources = await store.resolve(Resources);
    if (options.fixesFilters && ids.length) {
      if (!resources.checksums[DNR_FIXES_KEY] || lastOptions?.filtersUpdatedAt < options.filtersUpdatedAt) {
        const removeRuleIds = await getDynamicRulesIds(FIXES_ID_RANGE);
        try {
          console.info("[dnr] Updating dynamic fixes rules...");
          const list = await fetch(`${ENGINE_CONFIGS_ROOT_URL}/dnr-fixes-v2/allowed-lists.json`, {
            // Force no caching if update was triggered by the user ("Update now" action)
            cache: lastOptions && lastOptions.filtersUpdatedAt > Date.now() - UPDATE_ENGINES_DELAY ? "no-store" : "default"
          }).then(
            (res) => res.ok ? res.json() : Promise.reject(new Error(`Failed to fetch allowed lists: ${res.statusText}`))
          );
          if (list.dnr.checksum !== resources.checksums[DNR_FIXES_KEY]) {
            const rules = new Set(
              await fetch(list.dnr.url).then(
                (res) => res.ok ? res.json() : Promise.reject(new Error(`Failed to fetch DNR rules: ${res.statusText}`))
              ).then(filterMaxPriorityRules)
            );
            for (const rule of rules) {
              if (rule.condition.regexFilter) {
                const { isSupported } = await chrome.declarativeNetRequest.isRegexSupported({
                  regex: rule.condition.regexFilter
                });
                if (!isSupported) {
                  rules.delete(rule);
                }
              }
            }
            await chrome.declarativeNetRequest.updateDynamicRules({
              removeRuleIds: await getDynamicRulesIds(FIXES_ID_RANGE),
              addRules: Array.from(rules).map((rule, index) => ({
                ...rule,
                id: FIXES_ID_RANGE.start + index
              }))
            });
            console.info("[dnr] Updated dynamic fixes rules:", list.dnr.checksum);
            await store.set(Resources, {
              checksums: { [DNR_FIXES_KEY]: list.dnr.checksum }
            });
            await updateRedirectProtectionRules(options);
          }
        } catch (e) {
          console.error("[dnr] Error while updating dynamic fixes rules:", e);
          if (!removeRuleIds.length) {
            console.warn("[dnr] Falling back to static fixes rules");
            ids.push("fixes");
            await store.set(Resources, {
              checksums: { [DNR_FIXES_KEY]: "filesystem" }
            });
          }
        }
      }
    } else if (resources.checksums[DNR_FIXES_KEY]) {
      const removeRuleIds = await getDynamicRulesIds(FIXES_ID_RANGE);
      if (removeRuleIds.length) {
        await chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds
        });
        await store.set(resources, {
          checksums: { [DNR_FIXES_KEY]: null }
        });
        console.info("[dnr] Removed dynamic fixes rules");
      }
    }
    const enableRulesetIds = [];
    const disableRulesetIds = [];
    for (const id of ids) {
      if (!enabledRulesetIds.includes(id)) {
        enableRulesetIds.push(id);
      }
    }
    for (const id of enabledRulesetIds) {
      if (!ids.includes(id)) {
        disableRulesetIds.push(id);
      }
    }
    if (enableRulesetIds.length || disableRulesetIds.length) {
      try {
        await chrome.declarativeNetRequest.updateEnabledRulesets({
          enableRulesetIds,
          disableRulesetIds
        });
        console.info("[dnr] Updated static rulesets:", ids.length ? ids.join(", ") : "none");
      } catch (e) {
        console.error(`[dnr] Error while updating static rulesets:`, e);
      }
    }
  });
}
