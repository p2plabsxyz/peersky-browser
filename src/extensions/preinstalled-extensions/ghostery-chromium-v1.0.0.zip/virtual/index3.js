var isCidr = {exports: {}};

export { isCidr as __module };
