var CSSImportRule = {};

export { CSSImportRule as __exports };
