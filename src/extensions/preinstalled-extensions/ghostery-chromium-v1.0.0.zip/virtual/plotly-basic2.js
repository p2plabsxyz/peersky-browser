var plotlyBasic = {exports: {}};

export { plotlyBasic as __module };
