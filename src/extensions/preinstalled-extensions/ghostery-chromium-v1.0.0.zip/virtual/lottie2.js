var lottie = {exports: {}};

export { lottie as __module };
