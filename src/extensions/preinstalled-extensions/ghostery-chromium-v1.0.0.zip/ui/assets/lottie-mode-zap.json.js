const modeZapScreenshotUrl = "/assets/lottie-mode-zap-4QZjvDoQ.json";

export { modeZapScreenshotUrl as default };
