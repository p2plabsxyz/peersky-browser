const modifiedImageUrl = "/assets/trackers-modified-C5epsL3u.svg";

export { modifiedImageUrl as default };
