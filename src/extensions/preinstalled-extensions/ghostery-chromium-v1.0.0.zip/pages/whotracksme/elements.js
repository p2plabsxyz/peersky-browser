import __vite_glob_0_0 from './components/button.js';
import __vite_glob_0_1 from './components/sankey-chart.js';
import __vite_glob_0_2 from './components/trends-chart.js';
import define from '../../npm/hybrids/src/define.js';

define.from(
  /* #__PURE__ */ Object.assign({"./components/button.js": __vite_glob_0_0,"./components/sankey-chart.js": __vite_glob_0_1,"./components/trends-chart.js": __vite_glob_0_2


}),
  { root: ['components'], prefix: 'whotracksme' },
);
