import __vite_glob_0_28 from './website-details.js';
import router from '../../../npm/hybrids/src/router.js';
import { html } from '../../../npm/hybrids/src/template/index.js';
import { msg } from '../../../npm/hybrids/src/localize.js';

/**
 * Ghostery Browser Extension
 * https://www.ghostery.com/
 *
 * Copyright 2017-present Ghostery GmbH. All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0
 */


function clearCookies(host, event) {
  host.error = '';

  router.resolve(
    event,
    chrome.runtime
      .sendMessage({
        action: 'cookies:clean',
        domain: host.domain,
      })
      .then((result) => {
        if (!result.success) {
          host.error = msg`Failed to clear cookies: ${result.error}`;
          throw new Error(host.error);
        }

        return result;
      }),
  );
}

const __vite_glob_0_27 = {
  [router.connect]: { dialog: true },
  domain: '',
  error: '',
  render: ({ domain, error }) => html`
    <template layout>
      <settings-dialog>
        <div layout="block:center column gap:2">
          <ui-text type="label-l">Clear cookies?</ui-text>
          <ui-text type="body-s" color="tertiary">
            You’re about to remove all cookies stored by ${domain}.
          </ui-text>
          <ui-text type="body-s" color="tertiary">
            This will sign you out and may reset preferences or saved settings. Some pages may not
            work until you sign in or accept cookies again.
          </ui-text>
          ${error && html`<ui-text type="body-s" color="warning-primary"> ${error} </ui-text>`}
        </div>
        <div layout="grid:2 gap margin:top:3">
          <ui-button>
            <a href="${router.backUrl()}">Cancel</a>
          </ui-button>
          <ui-button type="danger" data-qa="button:confirm-clear-cookies">
            <a
              onclick="${clearCookies}"
              href="${router.url(__vite_glob_0_28, {
                domain,
                clearedCookies: true,
              })}"
            >
              Clear cookies
            </a>
          </ui-button>
        </div>
      </settings-dialog>
    </template>
  `,
};

export { __vite_glob_0_27 as default };
