const __vite_glob_0_3 = "/assets/pause_assistant-BA9OEfra.svg";

export { __vite_glob_0_3 as default };
