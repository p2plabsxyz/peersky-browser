const modeGhosteryScreenshotUrl = "/assets/lottie-mode-default-Drl5NLYc.json";

export { modeGhosteryScreenshotUrl as default };
