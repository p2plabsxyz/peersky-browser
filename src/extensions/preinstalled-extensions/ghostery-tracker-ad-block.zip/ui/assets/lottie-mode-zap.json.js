const modeZapScreenshotUrl = "/assets/lottie-mode-zap-CKqs_IMg.json";

export { modeZapScreenshotUrl as default };
