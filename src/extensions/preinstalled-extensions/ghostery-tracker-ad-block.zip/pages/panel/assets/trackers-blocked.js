const blockedImageUrl = "/assets/trackers-blocked-CGDDKs-l.svg";

export { blockedImageUrl as default };
