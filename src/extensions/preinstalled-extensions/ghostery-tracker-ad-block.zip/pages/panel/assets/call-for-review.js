const callForReviewImage = "/assets/call-for-review-CmEq1cfG.svg";

export { callForReviewImage as default };
