const sleep = "/assets/sleep-BmCTahGd.svg";

export { sleep as default };
