const contributionImage = "/assets/contribution-DqF7EuEI.svg";

export { contributionImage as default };
