const edgeMobileQrCodeImage = "/assets/edge-mobile-qr-code-DJyRRYQg.svg";

export { edgeMobileQrCodeImage as default };
