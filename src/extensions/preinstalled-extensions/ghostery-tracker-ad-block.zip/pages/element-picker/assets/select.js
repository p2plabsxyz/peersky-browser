const selectImage = "/assets/select-Brly4iPn.svg";

export { selectImage as default };
