const hiddenImage = "/assets/hidden-cXGyAdhW.svg";

export { hiddenImage as default };
