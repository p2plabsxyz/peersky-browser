import __vite_glob_0_0 from './components/container.js';
import __vite_glob_0_1 from './components/footer.js';
import __vite_glob_0_2 from './components/range.js';
import define from '../../npm/hybrids/src/define.js';

define.from(
  /* #__PURE__ */ Object.assign({"./components/container.js": __vite_glob_0_0,"./components/footer.js": __vite_glob_0_1,"./components/range.js": __vite_glob_0_2


}),
  { root: ['components', 'views'], prefix: 'element-picker' },
);
