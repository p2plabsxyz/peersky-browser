const pinExtensionChromeUrl = "/assets/pin-extension-chrome-BJM0T1sG.png";

export { pinExtensionChromeUrl as default };
