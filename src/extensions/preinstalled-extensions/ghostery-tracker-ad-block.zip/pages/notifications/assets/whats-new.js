const whatsNewImage = "/assets/whats-new-Cn-AG-oA.png";

export { whatsNewImage as default };
