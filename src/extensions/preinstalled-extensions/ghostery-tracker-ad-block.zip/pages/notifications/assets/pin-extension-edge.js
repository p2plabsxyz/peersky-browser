const pinExtensionEdgeUrl = "/assets/pin-extension-edge-DQsHZKMM.png";

export { pinExtensionEdgeUrl as default };
