const pinExtensionOperaUrl = "/assets/pin-extension-opera-jh_8wgB7.png";

export { pinExtensionOperaUrl as default };
