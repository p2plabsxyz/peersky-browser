const successDefaultImage = "/assets/success-default-cxtFo0JP.svg";

export { successDefaultImage as default };
