const successZapImage = "/assets/success-zap-CuBWT6Ju.svg";

export { successZapImage as default };
