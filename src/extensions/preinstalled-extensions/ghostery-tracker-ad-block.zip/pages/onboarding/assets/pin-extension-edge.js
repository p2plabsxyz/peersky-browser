const pinExtensionEdge = "/assets/pin-extension-edge-0ejqs-oy.jpg";

export { pinExtensionEdge as default };
