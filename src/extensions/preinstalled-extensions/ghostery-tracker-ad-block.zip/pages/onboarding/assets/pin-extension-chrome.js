const pinExtensionChrome = "/assets/pin-extension-chrome-jv4rqzUD.jpg";

export { pinExtensionChrome as default };
