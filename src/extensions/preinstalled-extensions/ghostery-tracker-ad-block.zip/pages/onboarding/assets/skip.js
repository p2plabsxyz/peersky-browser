const skipImage = "/assets/skip-D4RDmVhk.svg";

export { skipImage as default };
