const pinExtensionOpera = "/assets/pin-extension-opera-BZOrFlq9.jpg";

export { pinExtensionOpera as default };
