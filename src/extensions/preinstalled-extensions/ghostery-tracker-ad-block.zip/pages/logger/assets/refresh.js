const refreshImage = "/assets/refresh-B0nlARG8.svg";

export { refreshImage as default };
