const __vite_glob_0_0 = "/assets/feedback-vUK1L7gp.svg";

export { __vite_glob_0_0 as default };
