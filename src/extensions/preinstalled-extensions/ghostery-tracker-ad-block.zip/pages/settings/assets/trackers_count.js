const __vite_glob_0_5 = "/assets/trackers_count-BMdZln1a.svg";

export { __vite_glob_0_5 as default };
