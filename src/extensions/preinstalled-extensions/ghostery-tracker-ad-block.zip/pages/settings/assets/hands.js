const __vite_glob_0_1 = "/assets/hands-Dy0ClsPv.svg";

export { __vite_glob_0_1 as default };
