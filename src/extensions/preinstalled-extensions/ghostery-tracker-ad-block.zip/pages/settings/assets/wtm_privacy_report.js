const __vite_glob_0_7 = "/assets/wtm_privacy_report-DRHGsmiv.svg";

export { __vite_glob_0_7 as default };
