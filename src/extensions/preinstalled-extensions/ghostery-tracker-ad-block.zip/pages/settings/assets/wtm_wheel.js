const __vite_glob_0_8 = "/assets/wtm_wheel-Cz_iaTr1.svg";

export { __vite_glob_0_8 as default };
