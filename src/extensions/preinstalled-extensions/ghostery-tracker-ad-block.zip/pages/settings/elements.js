import __vite_glob_0_0 from './components/badge.js';
import __vite_glob_0_1 from './components/card.js';
import __vite_glob_0_2 from './components/devtools.js';
import __vite_glob_0_3 from './components/dialog.js';
import __vite_glob_0_4 from './components/exception-toggle.js';
import __vite_glob_0_5 from './components/help-image.js';
import __vite_glob_0_6 from './components/layout.js';
import __vite_glob_0_7 from './components/link.js';
import __vite_glob_0_8 from './components/managed.js';
import __vite_glob_0_9 from './components/option.js';
import __vite_glob_0_10 from './components/page-layout.js';
import __vite_glob_0_11 from './components/protection-badge.js';
import __vite_glob_0_12 from './components/protection-status.js';
import __vite_glob_0_13 from './components/table.js';
import __vite_glob_0_14 from './components/trackers-list.js';
import __vite_glob_0_15 from './components/wtm-link.js';
import __vite_glob_0_16 from './views/custom-filters.js';
import __vite_glob_0_17 from './views/experimental-filters.js';
import __vite_glob_0_18 from './views/my-ghostery.js';
import __vite_glob_0_19 from './views/privacy.js';
import __vite_glob_0_20 from './views/redirect-protection-add-exception.js';
import __vite_glob_0_21 from './views/redirect-protection.js';
import __vite_glob_0_22 from './views/regional-filters.js';
import __vite_glob_0_23 from './views/serp.js';
import __vite_glob_0_24 from './views/tracker-add-exception.js';
import __vite_glob_0_25 from './views/tracker-details.js';
import __vite_glob_0_26 from './views/trackers.js';
import __vite_glob_0_27 from './views/website-clear-cookies.js';
import __vite_glob_0_28 from './views/website-details.js';
import __vite_glob_0_29 from './views/websites-add.js';
import __vite_glob_0_30 from './views/websites.js';
import __vite_glob_0_31 from './views/whotracksme.js';
import define from '../../npm/hybrids/src/define.js';

define.from(
  /* #__PURE__ */ Object.assign({"./components/badge.js": __vite_glob_0_0,"./components/card.js": __vite_glob_0_1,"./components/devtools.js": __vite_glob_0_2,"./components/dialog.js": __vite_glob_0_3,"./components/exception-toggle.js": __vite_glob_0_4,"./components/help-image.js": __vite_glob_0_5,"./components/layout.js": __vite_glob_0_6,"./components/link.js": __vite_glob_0_7,"./components/managed.js": __vite_glob_0_8,"./components/option.js": __vite_glob_0_9,"./components/page-layout.js": __vite_glob_0_10,"./components/protection-badge.js": __vite_glob_0_11,"./components/protection-status.js": __vite_glob_0_12,"./components/table.js": __vite_glob_0_13,"./components/trackers-list.js": __vite_glob_0_14,"./components/wtm-link.js": __vite_glob_0_15,"./views/custom-filters.js": __vite_glob_0_16,"./views/experimental-filters.js": __vite_glob_0_17,"./views/my-ghostery.js": __vite_glob_0_18,"./views/privacy.js": __vite_glob_0_19,"./views/redirect-protection-add-exception.js": __vite_glob_0_20,"./views/redirect-protection.js": __vite_glob_0_21,"./views/regional-filters.js": __vite_glob_0_22,"./views/serp.js": __vite_glob_0_23,"./views/tracker-add-exception.js": __vite_glob_0_24,"./views/tracker-details.js": __vite_glob_0_25,"./views/trackers.js": __vite_glob_0_26,"./views/website-clear-cookies.js": __vite_glob_0_27,"./views/website-details.js": __vite_glob_0_28,"./views/websites-add.js": __vite_glob_0_29,"./views/websites.js": __vite_glob_0_30,"./views/whotracksme.js": __vite_glob_0_31


}),
  { root: ['components', 'views'], prefix: 'settings' },
);
