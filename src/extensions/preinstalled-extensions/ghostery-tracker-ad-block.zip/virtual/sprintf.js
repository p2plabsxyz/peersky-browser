import { __require as requireSprintf } from '../npm/sprintf-js/src/sprintf.js';

var sprintfExports = requireSprintf();

export { sprintfExports };
