var CSSRule = {};

export { CSSRule as __exports };
