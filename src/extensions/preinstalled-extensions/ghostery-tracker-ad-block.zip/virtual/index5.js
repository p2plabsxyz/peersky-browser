var cidrRegex = {exports: {}};

export { cidrRegex as __module };
