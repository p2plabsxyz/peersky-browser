var loader = {};

export { loader as __exports };
