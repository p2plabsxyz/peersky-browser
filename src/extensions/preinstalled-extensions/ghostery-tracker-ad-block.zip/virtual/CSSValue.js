var CSSValue = {};

export { CSSValue as __exports };
