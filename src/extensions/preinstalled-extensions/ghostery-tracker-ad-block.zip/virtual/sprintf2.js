var sprintf = {};

export { sprintf as __exports };
