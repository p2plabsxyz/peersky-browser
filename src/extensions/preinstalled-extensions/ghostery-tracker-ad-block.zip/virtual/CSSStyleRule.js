var CSSStyleRule = {};

export { CSSStyleRule as __exports };
