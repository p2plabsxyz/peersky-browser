import * as __viteOptionalPeerDep_canvas_linkedom_true from './__vite-optional-peer-dep_canvas_linkedom_true.js';
import { getAugmentedNamespace } from './_commonjsHelpers.js';

const require$$0 = /*@__PURE__*/getAugmentedNamespace(__viteOptionalPeerDep_canvas_linkedom_true);

export { require$$0 as default };
