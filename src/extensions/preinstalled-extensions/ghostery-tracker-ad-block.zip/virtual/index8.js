import { __require as requireLib } from '../npm/cssom/lib/index.js';

var libExports = requireLib();

export { libExports };
