var FileSaver_min = {exports: {}};

export { FileSaver_min as __module };
