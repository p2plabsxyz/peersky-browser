var CSSDocumentRule = {};

export { CSSDocumentRule as __exports };
