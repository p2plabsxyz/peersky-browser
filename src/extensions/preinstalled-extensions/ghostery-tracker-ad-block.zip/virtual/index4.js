import { __require as requireJsYaml } from '../npm/js-yaml/index.js';

requireJsYaml();
