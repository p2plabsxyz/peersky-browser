const __viteOptionalPeerDep_canvas_linkedom_true = {};

export { __viteOptionalPeerDep_canvas_linkedom_true as default };
