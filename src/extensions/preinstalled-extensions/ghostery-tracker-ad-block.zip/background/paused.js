import Options, { MODE_DEFAULT, GLOBAL_PAUSE_ID } from '../store/options.js';
import { addListener, isOptionEqual } from '../utils/options-observer.js';
import ManagedConfig, { TRUSTED_DOMAINS_NONE_ID } from '../store/managed-config.js';
import { getDynamicRulesIds, ALL_RESOURCE_TYPES, PAUSED_RULE_PRIORITY, PAUSED_ID_RANGE } from '../utils/dnr.js';
import store from '../npm/hybrids/src/store.js';

const PAUSED_ALARM_PREFIX = "options:revoke";
addListener(async function pausedSites(options, lastOptions) {
  if (options.mode !== MODE_DEFAULT) {
    if (lastOptions && options.mode !== lastOptions?.mode) {
      (await chrome.alarms.getAll()).forEach(({ name }) => {
        if (name.startsWith(PAUSED_ALARM_PREFIX)) {
          chrome.alarms.clear(name);
        }
      });
    }
    return;
  }
  const alarms = (await chrome.alarms.getAll()).filter(
    ({ name }) => name.startsWith(PAUSED_ALARM_PREFIX)
  );
  const revokeHostnames = Object.entries(options.paused).filter(
    ([, { revokeAt }]) => revokeAt
  );
  alarms.forEach(({ name }) => {
    if (!revokeHostnames.find(([id]) => name === `${PAUSED_ALARM_PREFIX}:${id}`)) {
      chrome.alarms.clear(name);
    }
  });
  if (revokeHostnames.length) {
    revokeHostnames.filter(([id]) => !alarms.some(({ name }) => name === id)).forEach(([id, { revokeAt }]) => {
      chrome.alarms.create(`${PAUSED_ALARM_PREFIX}:${id}`, {
        when: revokeAt
      });
    });
  }
  if (
    // Paused state has changed by the user interaction
    lastOptions && !isOptionEqual(options.paused, lastOptions.paused) || // Filtering mode has changed
    lastOptions && options.mode !== lastOptions.mode || // Managed mode can update the rules at any time - so we need to update
    // the rules even if the paused state hasn't changed
    (await store.resolve(ManagedConfig)).trustedDomains[0] !== TRUSTED_DOMAINS_NONE_ID
  ) {
    const removeRuleIds = await getDynamicRulesIds(PAUSED_ID_RANGE);
    const hostnames = Object.keys(options.paused);
    let globalPause = false;
    if (hostnames.includes(GLOBAL_PAUSE_ID)) {
      globalPause = true;
    }
    if (hostnames.length) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        addRules: [
          {
            id: 1,
            priority: PAUSED_RULE_PRIORITY,
            action: { type: "allow" },
            condition: {
              initiatorDomains: globalPause ? void 0 : hostnames,
              resourceTypes: ALL_RESOURCE_TYPES
            }
          },
          {
            id: 2,
            priority: PAUSED_RULE_PRIORITY,
            action: { type: "allow" },
            condition: {
              requestDomains: globalPause ? void 0 : hostnames,
              resourceTypes: ALL_RESOURCE_TYPES
            }
          },
          {
            id: 3,
            priority: PAUSED_RULE_PRIORITY,
            action: { type: "allowAllRequests" },
            condition: {
              initiatorDomains: globalPause ? void 0 : hostnames,
              resourceTypes: ["main_frame"]
            }
          }
        ],
        removeRuleIds
      });
      console.log("[paused] Pause rules updated:", hostnames.join(", "));
    } else if (removeRuleIds.length) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds
      });
      console.log("[paused] Pause rules cleared");
    }
  }
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name.startsWith(PAUSED_ALARM_PREFIX)) {
    const id = alarm.name.slice(PAUSED_ALARM_PREFIX.length + 1);
    store.set(Options, { paused: { [id]: null } });
  }
});
