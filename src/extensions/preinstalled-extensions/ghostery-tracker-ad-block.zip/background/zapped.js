import { FLAG_MODES } from '../npm/@ghostery/config/dist/esm/flags.js';
import Config from '../store/config.js';
import Options, { MODE_DEFAULT, MODE_ZAP } from '../store/options.js';
import { isWebkit } from '../utils/browser-info.js';
import { getDynamicRulesIds, PAUSED_RULE_PRIORITY, PAUSED_ID_RANGE } from '../utils/dnr.js';
import { addListener, isOptionEqual } from '../utils/options-observer.js';
import store from '../npm/hybrids/src/store.js';

store.observe(Config, async (_, config, lastConfig) => {
  if (lastConfig?.hasFlag(FLAG_MODES) && !config.hasFlag(FLAG_MODES)) {
    const removeRuleIds = await getDynamicRulesIds(PAUSED_ID_RANGE);
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds
    });
    await store.set(Options, {
      mode: MODE_DEFAULT,
      zapped: null
    });
    console.log(
      `[zapped] Filtering mode flag removed, resetting filtering mode and zapped data`
    );
  }
});
{
  addListener(async function zapped(options, lastOptions) {
    if (
      // No changes in options
      !lastOptions || // Filtering mode is not zap
      options.mode !== MODE_ZAP || // Filtering mode didn't change and 'zapped' option is equal
      options.mode === lastOptions.mode && isOptionEqual(options.zapped, lastOptions.zapped)
    ) {
      return;
    }
    const removeRuleIds = await getDynamicRulesIds(PAUSED_ID_RANGE);
    const excludedDomains = Object.keys(options.zapped);
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        isWebkit() ? (
          // TODO: Safari/WebKit has a bug with setting excludedRequestDomains,
          // it simply doesn't work and still allow on excluded domains
          // the only way is to use `allow` action with excludedInitiatorDomains
          {
            id: 1,
            priority: PAUSED_RULE_PRIORITY,
            action: { type: "allow" },
            condition: { excludedInitiatorDomains: excludedDomains }
          }
        ) : {
          id: 1,
          priority: PAUSED_RULE_PRIORITY,
          action: { type: "allowAllRequests" },
          condition: {
            excludedRequestDomains: excludedDomains,
            resourceTypes: ["main_frame"]
          }
        }
      ],
      removeRuleIds
    });
    console.log(`[zapped] Zap mode rules updated`);
  });
}
