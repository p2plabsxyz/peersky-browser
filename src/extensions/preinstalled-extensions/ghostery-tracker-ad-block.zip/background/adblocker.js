import '../npm/@ghostery/adblocker-webextension/dist/esm/index.js';
import { parse } from '../npm/tldts-experimental/dist/es6/index.js';
import scriptlets from '../npm/@ghostery/scriptlets/index.js';
import { FLAG_CHROMIUM_INJECT_COSMETICS_ON_RESPONSE_STARTED, FLAG_EXTENDED_SELECTORS, FLAG_INJECTION_TARGET_DOCUMENT_ID } from '../npm/@ghostery/config/dist/esm/flags.js';
import { resolveFlag } from '../store/config.js';
import Options, { ENGINES, getPausedDetails } from '../store/options.js';
import { isWebkit } from '../utils/browser-info.js';
import { init, setEnv, FIXES_ENGINE, ELEMENT_PICKER_ENGINE, CUSTOM_ENGINE, replace, create, isPersistentEngine, update, TRACKERDB_ENGINE, MAIN_ENGINE, get } from '../utils/engines.js';
import { setup as setup$1 } from '../utils/trackerdb.js';
import { addListener } from '../utils/options-observer.js';
import '../npm/@ghostery/adblocker/dist/esm/data-view.js';
import '../npm/@ghostery/adblocker/dist/esm/fetch.js';
import '../npm/@ghostery/adblocker/dist/esm/filters/cosmetic.js';
import '../npm/@ghostery/adblocker/dist/esm/lists.js';
import '../npm/@ghostery/adblocker/dist/esm/request.js';
import '../npm/@remusao/small/dist/esm/index.js';
import '../npm/@ghostery/adblocker/dist/esm/filters/network.js';
import '../npm/@ghostery/adblocker/dist/esm/preprocessor.js';
import asyncSetup from '../utils/setup.js';
import { tabStats } from './stats.js';
import './redirect-protection.js';
import store from '../npm/hybrids/src/store.js';

let options = Options;
function getEnabledEngines(config) {
  if (config.terms) {
    const list = ENGINES.filter(({ key }) => config[key]).map(
      ({ name }) => name
    );
    if (config.regionalFilters.enabled) {
      list.push(...config.regionalFilters.regions.map((id) => `lang-${id}`));
    }
    if (config.fixesFilters && list.length) {
      list.push(FIXES_ENGINE);
    }
    list.push(ELEMENT_PICKER_ENGINE);
    if (config.customFilters.enabled) {
      list.push(CUSTOM_ENGINE);
    }
    return list;
  }
  return [];
}
function pause(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function reloadMainEngine() {
  if (isWebkit()) await pause(1e3);
  const enabledEngines = getEnabledEngines(options);
  const resolvedEngines = (await Promise.all(
    enabledEngines.map(
      (id) => init(id).catch(() => {
        console.error(`[adblocker] failed to load engine: ${id}`);
        return null;
      }).then((engine) => {
        if (!engine) {
          enabledEngines.splice(enabledEngines.indexOf(id), 1);
        }
        return engine;
      })
    )
  )).filter((engine) => engine);
  if (resolvedEngines.length) {
    replace(MAIN_ENGINE, resolvedEngines);
    console.info(
      `[adblocker] Main engine reloaded with: ${enabledEngines.join(", ")}`
    );
  } else {
    await create(MAIN_ENGINE);
    console.info("[adblocker] Main engine reloaded with no filters");
  }
}
let updating = false;
async function updateEngines({ cache = true } = {}) {
  if (updating) return;
  try {
    updating = true;
    const enabledEngines = getEnabledEngines(options);
    if (enabledEngines.length) {
      let updated = false;
      await Promise.all(
        enabledEngines.filter(isPersistentEngine).map(async (id) => {
          await init(id);
          updated = await update(id, { cache }) || updated;
        })
      );
      setup$1.pending && await setup$1.pending;
      await update(TRACKERDB_ENGINE, { cache });
      await store.set(Options, { filtersUpdatedAt: Date.now() });
      if (updated) await reloadMainEngine();
    }
  } finally {
    updating = false;
  }
}
const UPDATE_ENGINES_DELAY = 60 * 60 * 1e3;
const setup = asyncSetup("adblocker", [
  addListener(
    async function adblockerEngines(value, lastValue) {
      options = value;
      const enabledEngines = getEnabledEngines(value);
      const lastEnabledEngines = lastValue && getEnabledEngines(lastValue);
      if (
        // Reload/mismatched main engine
        !await init(MAIN_ENGINE) || // Enabled engines changed
        lastEnabledEngines && (enabledEngines.length !== lastEnabledEngines.length || enabledEngines.some((id, i) => id !== lastEnabledEngines[i]))
      ) {
        await reloadMainEngine();
      }
      if (options.filtersUpdatedAt < Date.now() - UPDATE_ENGINES_DELAY) {
        await updateEngines();
      }
    }
  ),
  addListener(
    "experimentalFilters",
    async (value, lastValue) => {
      setEnv("env_experimental", value);
      if (lastValue !== void 0 && value) {
        await updateEngines();
      }
    }
  )
]);
const INJECTION_TARGET_DOCUMENT_ID = resolveFlag(
  FLAG_INJECTION_TARGET_DOCUMENT_ID
);
function resolveInjectionTarget(details) {
  const target = { tabId: details.tabId };
  if (INJECTION_TARGET_DOCUMENT_ID.enabled && details.documentId) {
    target.documentIds = [details.documentId];
  } else {
    target.frameIds = [details.frameId];
  }
  return target;
}
const scriptletGlobals = {
  // Request a real extension resource to obtain a dynamic ID to the resource.
  // Redirect resources are defined with `use_dynamic_url` restriction.
  // The dynamic ID is generated per session.
  // refs https://developer.chrome.com/docs/extensions/reference/manifest/web-accessible-resources#manifest_declaration
  warOrigin: chrome.runtime.getURL("/rule_resources/redirects/empty").slice(0, -6)
};
function injectScriptlets(filters, hostname, details) {
  for (const filter of filters) {
    const parsed = filter.parseScript();
    if (!parsed) {
      console.warn(
        "[adblocker] could not inject script filter:",
        filter.toString()
      );
      continue;
    }
    const scriptletName = `${parsed.name}${parsed.name.endsWith(".js") ? "" : ".js"}`;
    const scriptlet = scriptlets[scriptletName];
    if (!scriptlet) {
      console.warn("[adblocker] unknown scriptlet with name:", scriptletName);
      continue;
    }
    const func = scriptlet.func;
    const args = [
      scriptletGlobals,
      ...parsed.args.map((arg) => decodeURIComponent(arg))
    ];
    chrome.scripting.executeScript(
      {
        injectImmediately: true,
        world: chrome.scripting.ExecutionWorld?.MAIN ?? ("MAIN"),
        target: resolveInjectionTarget(details),
        func,
        args
      },
      () => {
        if (chrome.runtime.lastError) {
          console.warn(chrome.runtime.lastError);
        }
      }
    );
  }
}
function injectStyles(styles, details) {
  chrome.scripting.insertCSS({
    css: styles,
    origin: "USER",
    target: resolveInjectionTarget(details)
  }).catch((e) => console.warn("[adblocker] failed to inject CSS", e));
}
const EXTENDED_SELECTORS = resolveFlag(FLAG_EXTENDED_SELECTORS);
async function injectCosmetics(details, config) {
  const { bootstrap: isBootstrap = false, scriptletsOnly } = config;
  try {
    setup.pending && await setup.pending;
  } catch (e) {
    console.error("[adblocker] not ready for cosmetic injection", e);
    return;
  }
  const { frameId, url, tabId } = details;
  const parsed = parse(url);
  const domain = parsed.domain || "";
  const hostname = parsed.hostname || "";
  if (getPausedDetails(options, hostname)) return;
  const tabHostname = tabStats.get(tabId)?.hostname;
  if (tabHostname && getPausedDetails(options, tabHostname)) {
    return;
  }
  const engine = get(MAIN_ENGINE);
  {
    const { matches } = engine.matchCosmeticFilters({
      domain,
      hostname,
      url,
      classes: config.classes,
      hrefs: config.hrefs,
      ids: config.ids,
      // This needs to be done only once per frame
      getInjectionRules: isBootstrap,
      getExtendedRules: isBootstrap,
      getRulesFromHostname: isBootstrap,
      getPureHasRules: true,
      // This will be done every time we get information about DOM mutation
      getRulesFromDOM: !isBootstrap,
      callerContext: { tabId }
    });
    const styleFilters = [];
    const scriptFilters = [];
    for (const { filter, exception } of matches) {
      if (exception === void 0) {
        if (filter.isScriptInject()) {
          scriptFilters.push(filter);
        } else {
          styleFilters.push(filter);
        }
      }
    }
    if (isBootstrap) {
      injectScriptlets(scriptFilters, hostname, details);
    }
    if (scriptletsOnly) {
      return;
    }
    const { styles, extended } = engine.injectCosmeticFilters(styleFilters, {
      url,
      injectScriptlets: isBootstrap,
      injectExtended: isBootstrap,
      injectPureHasSafely: true,
      allowGenericHides: false,
      getBaseRules: false
    });
    if (styles) {
      injectStyles(styles, details);
    }
    if (EXTENDED_SELECTORS.enabled && extended && extended.length > 0) {
      chrome.tabs.sendMessage(
        tabId,
        { action: "evaluateExtendedSelectors", extended },
        { frameId }
      );
    }
  }
  if (isBootstrap) {
    const { styles } = engine.getCosmeticsFilters({
      domain,
      hostname,
      url,
      getBaseRules: true,
      getInjectionRules: false,
      getExtendedRules: false,
      getRulesFromDOM: false,
      getRulesFromHostname: false
    });
    injectStyles(styles, details);
  }
}
chrome.webNavigation.onCommitted.addListener(
  (details) => injectCosmetics(details, { bootstrap: true }),
  { url: [{ urlPrefix: "http://" }, { urlPrefix: "https://" }] }
);
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.action === "injectCosmetics" && sender.tab) {
    const url = !sender.url.startsWith("http") ? sender.origin : sender.url;
    const details = {
      url,
      tabId: sender.tab.id,
      frameId: sender.frameId
    };
    injectCosmetics(details, msg);
  }
});
{
  let INJECT_COSMETICS_ON_RESPONSE_STARTED = resolveFlag(
    FLAG_CHROMIUM_INJECT_COSMETICS_ON_RESPONSE_STARTED
  );
  chrome.webRequest?.onResponseStarted.addListener(
    (details) => {
      if (!INJECT_COSMETICS_ON_RESPONSE_STARTED.enabled) return;
      if (details.tabId === -1) return;
      if (details.type !== "main_frame" && details.type !== "sub_frame") return;
      if (!details.documentId) return;
      injectCosmetics(details, { bootstrap: true });
    },
    { urls: ["http://*/*", "https://*/*"] }
  );
}

export { UPDATE_ENGINES_DELAY, reloadMainEngine, setup, updateEngines };
