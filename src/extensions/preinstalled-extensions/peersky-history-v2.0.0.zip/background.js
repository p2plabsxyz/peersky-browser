/* global chrome, IDBKeyRange, AbortController */

// Import the idb library
importScripts('idb.min.js');

if (!globalThis.browser) globalThis.browser = chrome;

const TAB_CHECK_DELAY = 100;
const HISTORY_DB = 'history';
const HISTORY_VERSION = 2;

const HISTORY_STORE = 'navigated';
const MAX_RESULTS = 8;

const FORBIDDEN_PROTOCOLS = [
  'peersky:',
  'browser:',
  'chrome-extension:',
  'chrome:',
  'devtools:',
  'file:',
  'about:',
  'view-source:',
  'data:',
  'blob:'
];

main();

async function main() {
  const db = await idb.openDB(HISTORY_DB, HISTORY_VERSION, {
    upgrade
  });

  let aborter = null;

  chrome.webNavigation.onCompleted.addListener(onCompleted);
  
  // Open view.html in a new tab when extension icon is clicked
  chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL('view.html') });
  });
  globalThis.db = db;
  globalThis.search = search;

  async function* search(query = '', maxResults = MAX_RESULTS, _signal) {
    let signal = _signal;
    if (!signal) {
      if (aborter) aborter.abort();
      aborter = new AbortController();
      signal = aborter.signal;
    }
    let sent = 0;
    const seen = new Set();

    const regexText = query.split(' ').reduce((result, letter) => `${result}.*${letter}`, '');
    const filter = new RegExp(regexText, 'iu');

    let start = Date.now();
    const range = IDBKeyRange.upperBound(start);
    let cursor = await db
      .transaction(HISTORY_STORE, 'readonly')
      .store.index('timestamp')
      .openCursor(range, 'prev');

    while (cursor) {
      const {key, value} = cursor;
      start = key;
      const { search: searchString, url } = value;
      if (searchString.match(filter) && !seen.has(url)) {
        seen.add(url);
        yield value;
        sent++;
        if (sent >= maxResults) break;
        const range = IDBKeyRange.upperBound(start);
        cursor = await db
          .transaction(HISTORY_STORE, 'readonly')
          .store.index('timestamp')
          .openCursor(range, 'prev');
      }
      if (signal && signal.aborted) {
        break;
      }
      cursor = await cursor.continue();
    }
  }

  async function onCompleted ({ timeStamp, tabId }) {
    await delay(TAB_CHECK_DELAY);

    const tab = await getTab(tabId);
    const { url, title } = tab;

    const parsedUrl = parseUrlSafe(url);
    if (shouldSkipUrl(parsedUrl)) return;
    const { host, protocol, pathname } = parsedUrl;

    const historyItem = {
      host,
      protocol,
      pathname,
      url,
      title,
      timestamp: timeStamp,
      search: `${url} ${title}`
    };

    // console.log('Navigation event', historyItem)

    await db.add(HISTORY_STORE, historyItem);
  }
}

async function upgrade (db) {
  if (db.objectStoreNames.contains(HISTORY_STORE)) return;

  const store = db.createObjectStore(HISTORY_STORE, {
    // The 'id' property of the object will be the key.
    keyPath: 'id',
    // If it isn't explicitly set, create a value by auto incrementing.
    autoIncrement: true
  });

  store.createIndex('search', 'search', { unique: false });
  store.createIndex('timestamp', 'timestamp', { unique: false });
  store.createIndex('url', 'url', { unique: false });
  store.createIndex('title', 'title', { unique: false });
  store.createIndex('host', 'host', { unique: false });
  store.createIndex('protocol', 'protocol', { unique: false });
}

async function getTab (id) {
  return new Promise((resolve) => {
    chrome.tabs.get(id, resolve);
  });
}

async function delay (ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function parseUrlSafe (rawUrl) {
  try {
    return new URL(rawUrl);
  } catch (error) {
    return null;
  }
}

function shouldSkipUrl (parsedUrl) {
  if (!parsedUrl) return true;
  return FORBIDDEN_PROTOCOLS.includes(parsedUrl.protocol);
}
