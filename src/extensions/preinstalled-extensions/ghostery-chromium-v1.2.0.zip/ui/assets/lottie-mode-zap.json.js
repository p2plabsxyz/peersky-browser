//#region src/ui/assets/lottie-mode-zap.json?url
var lottie_mode_zap_default = "/assets/lottie-mode-zap.json-Dd1fuCpJ.json";
//#endregion
export { lottie_mode_zap_default as default };
