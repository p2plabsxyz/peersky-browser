//#region src/pages/panel/assets/contribution.svg
var contribution_default = "/assets/contribution.svg-B7HiQlRb.svg";
//#endregion
export { contribution_default as default };
