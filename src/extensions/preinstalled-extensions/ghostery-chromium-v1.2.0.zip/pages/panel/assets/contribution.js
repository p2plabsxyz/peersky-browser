//#region src/pages/panel/assets/contribution.svg
var contribution_default = "/assets/contribution.svg-DqF7EuEI.svg";
//#endregion
export { contribution_default as default };
