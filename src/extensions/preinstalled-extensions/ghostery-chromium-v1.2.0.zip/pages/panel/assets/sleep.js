//#region src/pages/panel/assets/sleep.svg
var sleep_default = "/assets/sleep.svg-DOll09CY.svg";
//#endregion
export { sleep_default as default };
