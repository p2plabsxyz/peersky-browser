//#region src/pages/panel/assets/call-for-survey.svg
var call_for_survey_default = "/assets/call-for-survey.svg-Ccw1zZqY.svg";
//#endregion
export { call_for_survey_default as default };
