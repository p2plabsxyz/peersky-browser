//#region src/pages/panel/assets/call-for-review.svg
var call_for_review_default = "/assets/call-for-review.svg-BPF6PhCL.svg";
//#endregion
export { call_for_review_default as default };
