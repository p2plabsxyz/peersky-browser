//#region src/pages/onboarding/assets/success-default.svg
var success_default_default = "/assets/success-default.svg-CJ3WjQmK.svg";
//#endregion
export { success_default_default as default };
