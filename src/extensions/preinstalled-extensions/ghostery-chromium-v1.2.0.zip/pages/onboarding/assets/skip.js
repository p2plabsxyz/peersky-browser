//#region src/pages/onboarding/assets/skip.svg
var skip_default = "/assets/skip.svg-D4RDmVhk.svg";
//#endregion
export { skip_default as default };
