//#region src/pages/onboarding/assets/skip.svg
var skip_default = "/assets/skip.svg-BnjRge6N.svg";
//#endregion
export { skip_default as default };
