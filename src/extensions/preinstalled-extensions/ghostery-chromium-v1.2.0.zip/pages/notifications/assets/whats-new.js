//#region src/pages/notifications/assets/whats-new.png
var whats_new_default = "/assets/whats-new.png-Cn-AG-oA.png";
//#endregion
export { whats_new_default as default };
