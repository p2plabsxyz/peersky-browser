//#region src/pages/logger/assets/refresh.svg
var refresh_default = "/assets/refresh.svg-BxrFwSEZ.svg";
//#endregion
export { refresh_default as default };
