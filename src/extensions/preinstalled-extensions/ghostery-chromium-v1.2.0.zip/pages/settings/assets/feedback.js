//#region src/pages/settings/assets/feedback.svg
var feedback_default = "/assets/feedback.svg-DpXk_6se.svg";
//#endregion
export { feedback_default as default };
