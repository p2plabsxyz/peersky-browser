//#region src/pages/settings/assets/feedback.svg
var feedback_default = "/assets/feedback.svg-vUK1L7gp.svg";
//#endregion
export { feedback_default as default };
