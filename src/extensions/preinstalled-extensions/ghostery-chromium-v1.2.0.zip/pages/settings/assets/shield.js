//#region src/pages/settings/assets/shield.svg
var shield_default = "/assets/shield.svg-DpD_1CWr.svg";
//#endregion
export { shield_default as default };
