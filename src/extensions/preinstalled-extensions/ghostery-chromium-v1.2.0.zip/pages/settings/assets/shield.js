//#region src/pages/settings/assets/shield.svg
var shield_default = "/assets/shield.svg-zgpCkU0K.svg";
//#endregion
export { shield_default as default };
