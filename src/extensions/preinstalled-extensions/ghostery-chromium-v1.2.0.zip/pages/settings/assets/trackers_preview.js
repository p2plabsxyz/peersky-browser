//#region src/pages/settings/assets/trackers_preview.svg
var trackers_preview_default = "/assets/trackers_preview.svg-6gMBeY8j.svg";
//#endregion
export { trackers_preview_default as default };
