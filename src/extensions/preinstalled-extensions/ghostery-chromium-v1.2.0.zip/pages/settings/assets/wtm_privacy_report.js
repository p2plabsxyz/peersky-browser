//#region src/pages/settings/assets/wtm_privacy_report.svg
var wtm_privacy_report_default = "/assets/wtm_privacy_report.svg-md7khnEe.svg";
//#endregion
export { wtm_privacy_report_default as default };
