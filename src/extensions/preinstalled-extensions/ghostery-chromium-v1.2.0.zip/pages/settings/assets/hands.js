//#region src/pages/settings/assets/hands.svg
var hands_default = "/assets/hands.svg-BYrijSm4.svg";
//#endregion
export { hands_default as default };
