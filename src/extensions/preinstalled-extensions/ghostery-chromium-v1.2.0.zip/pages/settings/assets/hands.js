//#region src/pages/settings/assets/hands.svg
var hands_default = "/assets/hands.svg-Dy0ClsPv.svg";
//#endregion
export { hands_default as default };
