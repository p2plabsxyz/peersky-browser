//#region src/pages/settings/assets/trackers_count.svg
var trackers_count_default = "/assets/trackers_count.svg-DifWVUp4.svg";
//#endregion
export { trackers_count_default as default };
