//#region src/pages/settings/assets/pause_assistant.svg
var pause_assistant_default = "/assets/pause_assistant.svg-C4UhZlH7.svg";
//#endregion
export { pause_assistant_default as default };
