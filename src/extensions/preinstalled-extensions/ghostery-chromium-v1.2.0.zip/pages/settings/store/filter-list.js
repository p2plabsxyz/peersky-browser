import store_default from "../../../npm/hybrids/src/store.js";
import { msg } from "../../../npm/hybrids/src/localize.js";
import Options from "../../../store/options.js";
//#region src/pages/settings/store/filter-list.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var filter_list_default = {
	id: true,
	url: "",
	[store_default.connect]: { async set(_, values) {
		const url = values.url.trim();
		if (!/^https?:/.test(url) || !URL.canParse(url)) throw msg`The URL is invalid`;
		if ((await store_default.resolve(Options)).customFilters.filterLists[url]) throw msg`The URL is already added`;
		return { url };
	} }
};
//#endregion
export { filter_list_default as default };
