//#region src/pages/element-picker/assets/select.svg
var select_default = "/assets/select.svg-OaelESTS.svg";
//#endregion
export { select_default as default };
