//#region src/pages/element-picker/assets/hidden.svg
var hidden_default = "/assets/hidden.svg-DTeHhwjP.svg";
//#endregion
export { hidden_default as default };
