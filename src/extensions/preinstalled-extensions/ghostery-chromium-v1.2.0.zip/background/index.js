import "../ui/localize.js";
import { bootstrapEmbedded, isEmbeddedHost } from "./peersky-bootstrap.js";
import "./config.js";
import "./onboarding.js";
import "./exceptions.js";
import "./redirect-protection.js";
import "./custom-filters/index.js";
import "./stats.js";
import "./adblocker/index.js";
import "./never-consent/index.js";
import "./cookies.js";
import "./distractions.js";
import "./element-picker.js";
import "./dnr.js";
import "./context-menu.js";
import "./paused.js";
import "./zapped.js";
import "./notifications.js";
import "./telemetry/index.js";
import "./serp.js";
import "./report-issue.js";
import "./pause-assistant.js";
import "./whats-new.js";
import "./helpers.js";
import "./sync.js";
import "./reporting/index.js";
import "./devtools.js";
import "./storage.js";
//#region src/background/index.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
if (isEmbeddedHost()) bootstrapEmbedded();
//#endregion
