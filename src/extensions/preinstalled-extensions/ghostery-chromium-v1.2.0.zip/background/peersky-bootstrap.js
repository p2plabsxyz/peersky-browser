import store_default from "../npm/hybrids/src/store.js";
import Options from "../store/options.js";
//#region src/background/peersky-bootstrap.js
/**
* Peersky hosts run Ghostery without the onboarding flow. The DNR module only
* enables filter rulesets after options.terms is set.
*/
function isEmbeddedHost() {
	if (typeof navigator === "undefined") return false;
	const ua = navigator.userAgent || "";
	return /Electron|Peersky/i.test(ua);
}
async function bootstrapEmbedded() {
	try {
		const { options = {}, managedConfig } = await chrome.storage.local.get(["options", "managedConfig"]);
		if (options.terms === false) return;
		if (!managedConfig?.disableOnboarding) await chrome.storage.local.set({ managedConfig: {
			...managedConfig || {},
			disableOnboarding: true
		} });
		if (!options.terms) await store_default.set(Options, {
			terms: true,
			blockAds: true,
			blockTrackers: true,
			blockAnnoyances: true,
			onboarding: true
		});
	} catch (e) {
		console.warn("[peersky-bootstrap] Failed:", e);
	}
}
//#endregion
export { bootstrapEmbedded, isEmbeddedHost };
