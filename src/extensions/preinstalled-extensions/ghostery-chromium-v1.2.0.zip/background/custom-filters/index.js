import store_default from "../../npm/hybrids/src/store.js";
import { msg } from "../../npm/hybrids/src/localize.js";
import CustomFilters from "../../store/custom-filters.js";
import ManagedConfig from "../../store/managed-config.js";
import Options from "../../store/options.js";
import { addListener, isOptionEqual } from "../../utils/options-observer.js";
import { FilterType, parseFilters } from "../../npm/@ghostery/adblocker/dist/esm/lists.js";
import "../../npm/@ghostery/adblocker/dist/esm/index.js";
import { CUSTOM_ENGINE, create, getConfig, init } from "../../utils/engines.js";
import { isUserScriptsSupported } from "../../utils/user-scripts.js";
import convert from "../../utils/dnr-converter.js";
import { updateDNRRules } from "./dnr.js";
import { cleanupFilterLists, refreshFilterLists } from "./filter-lists.js";
import { reloadMainEngine, setup } from "../adblocker/engines.js";
//#region src/background/custom-filters/index.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
function isTrustedScriptInject(scriptName) {
	return scriptName === "rpnt" || scriptName === "replace-node-text" || scriptName.startsWith("trusted-");
}
function encodeScriptletArguments(filter) {
	if (!filter.isScriptInject() || !filter.selector) return;
	const parsed = filter.parseScript();
	if (!parsed || !parsed.name) return;
	const encodedArgs = parsed.args.map((arg) => encodeURIComponent(arg));
	filter.selector = [parsed.name, ...encodedArgs].join(", ");
	filter.scriptletDetails = void 0;
}
function findLineNumber(text, line) {
	const index = text.indexOf(line);
	if (index === -1) return -1;
	if (index === 0) return 1;
	let lines = 1;
	for (let i = 0; i < index; i++) if (text.charCodeAt(i) === 10 || text.charCodeAt(i) === 13) lines++;
	return lines;
}
async function collectFilters(text, { trustedScriptlets }) {
	const { networkFilters, cosmeticFilters, preprocessors, notSupportedFilters } = parseFilters(text, {
		...await getConfig(),
		debug: true
	});
	const errors = notSupportedFilters.reduce(function(state, { filter, filterType, lineNumber }) {
		if (filterType !== FilterType.NOT_SUPPORTED_EMPTY && filterType !== FilterType.NOT_SUPPORTED_COMMENT) state.push(`Filter not supported (${lineNumber + 1}): ${filter}`);
		return state;
	}, []);
	const acceptedCosmeticFilters = cosmeticFilters.filter(function(filter) {
		if (filter.isScriptInject() === false || trustedScriptlets === true) return true;
		const scriptNameIndex = filter.selector.indexOf(",");
		if (isTrustedScriptInject(scriptNameIndex === -1 ? filter.selector : filter.selector.slice(0, scriptNameIndex))) {
			errors.push(`Trusted scriptlets are not allowed (${findLineNumber(text, filter.rawLine)}): ${filter.rawLine}`);
			return false;
		}
		return true;
	});
	for (const filter of acceptedCosmeticFilters) encodeScriptletArguments(filter);
	return {
		networkFilters,
		cosmeticFilters: acceptedCosmeticFilters,
		preprocessors,
		errors
	};
}
async function rebuildCustomFilters({ trustedScriptlets, filterLists }) {
	setup.pending && await setup.pending;
	const customFilters = await store_default.resolve(CustomFilters);
	const userScripts = isUserScriptsSupported();
	const sources = [{
		text: customFilters.text,
		trustedScriptlets,
		primary: true
	}];
	if (userScripts) for (const [url, { enabled, trustedScriptlets: urlTrustedScriptlets }] of Object.entries(filterLists)) {
		const text = customFilters.filterLists[url]?.text;
		if (enabled && text) sources.push({
			url,
			text,
			trustedScriptlets: urlTrustedScriptlets
		});
	}
	let networkFilters = [];
	let cosmeticFilters = [];
	let preprocessors = [];
	let errors = [];
	const listErrors = {};
	const filterIdToSource = /* @__PURE__ */ new Map();
	for (const source of sources) {
		const result = await collectFilters(source.text, { trustedScriptlets: source.trustedScriptlets });
		networkFilters = networkFilters.concat(result.networkFilters);
		cosmeticFilters = cosmeticFilters.concat(result.cosmeticFilters);
		preprocessors = preprocessors.concat(result.preprocessors);
		if (source.primary) errors = errors.concat(result.errors);
		else listErrors[source.url] = result.errors;
		for (const filter of result.networkFilters) filterIdToSource.set(filter.getId(), source.url);
	}
	const engine = await create(CUSTOM_ENGINE, {
		networkFilters,
		cosmeticFilters,
		preprocessors
	});
	let dnrRules = [];
	{
		const rawLinesBySource = /* @__PURE__ */ new Map();
		for (const filter of engine.getFilters().networkFilters) {
			if (engine.preprocessors.isFilterExcluded(filter)) continue;
			const url = filterIdToSource.get(filter.getId());
			const lines = rawLinesBySource.get(url);
			if (lines) lines.push(filter.rawLine);
			else rawLinesBySource.set(url, [filter.rawLine]);
		}
		let rules = [];
		for (const [url, lines] of rawLinesBySource) {
			const { rules: sourceRules, errors: convertErrors } = await convert(lines);
			rules = rules.concat(sourceRules);
			if (convertErrors?.length) if (url === void 0) errors = errors.concat(convertErrors);
			else listErrors[url] = (listErrors[url] || []).concat(convertErrors);
		}
		try {
			dnrRules = await updateDNRRules(rules);
		} catch (e) {
			errors.push(e.message);
		}
	}
	const values = await store_default.set(CustomFilters, {
		filterLists: Object.fromEntries(Object.keys(customFilters.filterLists).map((url) => [url, { errors: listErrors[url] || [] }])),
		networkFilters: engine.getFilters().networkFilters.length,
		cosmeticFilters: engine.getFilters().cosmeticFilters.length,
		dnrRules: dnrRules?.length || 0,
		userScripts,
		errors
	});
	console.info("[custom-filters] Engine rebuild completed with result:", values);
}
async function updateFilterLists({ cache = true } = {}) {
	console.info("[custom-filters] Refreshing remote filter lists...");
	if (await refreshFilterLists({ cache })) {
		await rebuildCustomFilters((await store_default.resolve(Options)).customFilters);
		return true;
	}
	return false;
}
addListener("customFilters", async (value, lastValue) => {
	if (value.enabled) {
		const managedConfig = await store_default.resolve(ManagedConfig);
		if (managedConfig.customFilters.enabled) {
			const currentText = (await store_default.resolve(CustomFilters)).text;
			const text = managedConfig.customFilters.filters.join("\n");
			if (text !== currentText) {
				await store_default.set(CustomFilters, { text });
				await rebuildCustomFilters(value);
				await reloadMainEngine();
				return;
			}
		}
	}
	if (!lastValue) {
		if (value.enabled && !await init("custom-filters")) {
			await rebuildCustomFilters(value);
			await reloadMainEngine();
		}
		if (value.enabled) {
			if ((await store_default.resolve(CustomFilters)).userScripts !== isUserScriptsSupported()) {
				await rebuildCustomFilters(value);
				await reloadMainEngine();
				return;
			}
		}
		return;
	}
	if (value.trustedScriptlets !== lastValue.trustedScriptlets) return;
	if (!isOptionEqual(value.filterLists, lastValue.filterLists)) {
		await cleanupFilterLists(value);
		if (value.enabled) {
			await refreshFilterLists();
			await rebuildCustomFilters(value);
			await reloadMainEngine();
			return;
		}
	}
	if (value.enabled && !lastValue.enabled) {
		await rebuildCustomFilters(value);
		await reloadMainEngine();
	}
	if (!value.enabled && lastValue.enabled) await updateDNRRules([]);
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	switch (message.action) {
		case "customFilters:updateRules":
			(async () => {
				try {
					await store_default.set(CustomFilters, { text: message.input });
					await rebuildCustomFilters((await store_default.resolve(Options)).customFilters);
					await reloadMainEngine();
					sendResponse(msg`Filter rules have been updated`);
				} catch (e) {
					await store_default.set(CustomFilters, { errors: [e.message] }).catch(() => {});
					sendResponse(msg`Failed to update filter rules`);
				}
			})();
			return true;
	}
});
//#endregion
export { updateFilterLists };
