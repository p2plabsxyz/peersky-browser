import { isSafari } from "./browser-info.js";
//#region src/utils/user-scripts.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
function isUserScriptsSupported() {
	if (isSafari()) return true;
	try {
		chrome.userScripts.getScripts();
		return true;
	} catch {
		return false;
	}
}
//#endregion
export { isUserScriptsSupported };
