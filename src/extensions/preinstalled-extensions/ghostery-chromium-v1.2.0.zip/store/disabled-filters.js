import store_default from "../npm/hybrids/src/store.js";
//#region src/store/disabled-filters.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var STORAGE_KEY = "disabledFilters";
var DisabledFilters = {
	ids: store_default.record(false),
	[store_default.connect]: {
		async get() {
			const { [STORAGE_KEY]: values = {} } = await chrome.storage.local.get([STORAGE_KEY]);
			return values;
		},
		async set(_, values) {
			await chrome.storage.local.set({ [STORAGE_KEY]: values });
			return values;
		}
	}
};
chrome.storage.onChanged.addListener((changes) => {
	if (changes[STORAGE_KEY]) store_default.clear(DisabledFilters, false);
});
//#endregion
export { DisabledFilters as default };
