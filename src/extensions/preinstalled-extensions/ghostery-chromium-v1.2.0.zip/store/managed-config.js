import store_default from "../npm/hybrids/src/store.js";
import { isOpera, isWebkit } from "../utils/browser-info.js";
//#region src/store/managed-config.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var ManagedConfig = {
	disableOnboarding: false,
	disableUserControl: false,
	disableUserAccount: false,
	disableTrackersPreview: false,
	trustedDomains: {
		enabled: false,
		domains: [String]
	},
	customFilters: {
		enabled: false,
		filters: [String]
	},
	disableNotifications: (config) => config.disableOnboarding || config.disableUserControl,
	disableModes: (config) => config.disableOnboarding || config.disableUserControl || config.trustedDomains.enabled || config.customFilters.enabled,
	[store_default.connect]: async () => {
		if (isOpera() || isWebkit()) return {};
		let { managedConfig } = await chrome.storage.local.get("managedConfig");
		{
			const managedConfigFromBackend = chrome.storage.managed.get().then(function(managedConfig) {
				chrome.storage.local.set({ managedConfig });
				return managedConfig;
			}).catch(function() {
				return {};
			});
			managedConfig ??= await managedConfigFromBackend;
		}
		if (managedConfig.trustedDomains) managedConfig.trustedDomains = {
			enabled: true,
			domains: managedConfig.trustedDomains
		};
		if (managedConfig.customFilters) managedConfig.customFilters = {
			enabled: true,
			filters: managedConfig.customFilters
		};
		return managedConfig;
	}
};
//#endregion
export { ManagedConfig as default };
