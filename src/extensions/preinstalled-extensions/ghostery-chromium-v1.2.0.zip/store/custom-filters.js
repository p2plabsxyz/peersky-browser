import store_default from "../npm/hybrids/src/store.js";
//#region src/store/custom-filters.js
/**
* Ghostery Browser Extension
* https://www.ghostery.com/
*
* Copyright 2017-present Ghostery GmbH. All rights reserved.
*
* This Source Code Form is subject to the terms of the Mozilla Public
* License, v. 2.0. If a copy of the MPL was not distributed with this
* file, You can obtain one at http://mozilla.org/MPL/2.0
*/
var CustomFilters = {
	text: "",
	filterLists: store_default.record({
		text: "",
		name: "",
		lastUpdatedAt: 0,
		expires: 0,
		error: "",
		errors: [String]
	}),
	networkFilters: 0,
	cosmeticFilters: 0,
	dnrRules: 0,
	userScripts: false,
	errors: [String],
	[store_default.connect]: {
		cache: false,
		async get() {
			let { customFilters } = await chrome.storage.local.get(["customFilters"]);
			if (!customFilters) {
				const { customFiltersInput } = await chrome.storage.local.get(["customFiltersInput"]);
				if (customFiltersInput !== void 0) {
					customFilters = { text: customFiltersInput };
					await chrome.storage.local.set({ customFilters });
					await chrome.storage.local.remove("customFiltersInput");
				}
			}
			return customFilters || {};
		},
		async set(_, values) {
			await chrome.storage.local.set({ customFilters: values });
			return values;
		}
	}
};
chrome.storage.onChanged.addListener((changes) => {
	if (changes["customFilters"]) store_default.clear(CustomFilters, false);
});
//#endregion
export { CustomFilters as default };
