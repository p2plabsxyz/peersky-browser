(function () { 'use strict'; window.eval = new Proxy(window.eval, { apply: function () {} }) })()
