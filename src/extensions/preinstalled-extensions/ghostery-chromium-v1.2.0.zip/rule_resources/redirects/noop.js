(function () { 'use strict' })()
